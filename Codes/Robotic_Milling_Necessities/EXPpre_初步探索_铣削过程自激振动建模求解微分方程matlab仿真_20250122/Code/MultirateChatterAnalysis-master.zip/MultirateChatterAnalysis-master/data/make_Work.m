%%%%%%%%%%
%EDIT HERE
Work.Kt=180*10^6*9.8; %Cutting Force Coefficient in the tangential direction
Work.Kn=0.3*Work.Kt; %Cutting Force Coefficient in the normal direction
%%%%%%%%%%

